import React from 'react';

export type HOC = {
  className?: string;
  children?: React.ReactNode;
};
